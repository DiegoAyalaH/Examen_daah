const Sequelize = require('sequelize');

const Videojuego = (sequelize)=>{
    sequelize.define('Videojuego',{
        //Forma especifica de declarar atributos
        nombre:{
            type: Sequelize.STRING,
            allowNull: false,
            primaryKey:true
        },
        lanzamiento:{
            type:Sequelize.STRING,
            
        },
        plataforma:{
            type:Sequelize.STRING,
            
        },
        genero:{
            type:Sequelize.STRING,
            
        }
    })
}
module.exports=Videojuego;