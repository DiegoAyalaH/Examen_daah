//Configuración de sequelize
const Sequelize = require('sequelize');

//Objeto de conexión
const sequelize = new Sequelize('Examen_DAAH','admin','HeNE730913',{
    dialect:'mysql',
    port:3306,
    host:'database-1.c9wbpdbxxano.us-east-1.rds.amazonaws.com',
    dialectOptions:{
        options:{
            //Características especiales de la conexión
        }
    },
    define:{
        timestamps: false,
        freezeTableName:true
    }
});

//Cargar los modelos
const modelDefiners =[
    require('../models/videojuego'),
];

//Adherir los modelos al objeto de conexion
for(const modelDefiner of modelDefiners){
    modelDefiner(sequelize);   
}

//Exportar el objeto sequelize
module.exports = sequelize;
