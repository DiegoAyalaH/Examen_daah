const express = require("express")
const VideoController = require('../controllers/videojuego')
const router = express.Router()

router.post('/agregarVideo',VideoController.postAgregarVideojuegos)
router.get('/consultaVideo',VideoController.getvidVideojuegos)
module.exports = router