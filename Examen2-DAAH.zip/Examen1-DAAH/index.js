const express = require("express");
const sequelize = require('./utils/database')
const Routes = require('./models/videojuego');
const app = express();
app.use(express.json());
const path = require('path');
app.use('/videojuego',Routes);
 //middleware
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(express.static(path.join(__dirname,'public')));

sequelize.sync()
    .then(
        app.listen(8081,()=>{
            console.log("Servidor online en el puerto 8081")
        })
    )
    .catch(error=>console.log(error))