const path = require("path");
const Videojuegos = require("../utils/database").models.Videojuego;
const sequelize = require("../utils/database");
const Sequeliza = require("sequelize");


exports.postAgregarVideojuegos=(req,res)=>{
    //DELETE FROM Consola
    console.log(req.body)
    Videojuegos.create(req.body)
    .then(resultado=>{
        console.log("Registro Exitoso");//Servidor
        res.send("RegistroExitoso");//Cliente
    })
    .catch(error=>{
        console.log(error);//Servidor
        res.send("Ocurrio un error")//Cliente
    })

}

exports.getvidVideojuegos=(req,res)=>{
    //Select * from consola
    Videojuegos.findAll()
        .then(videojuego=>{
            Console.log("Videojuegos:",videojuego);
            res.send(videojuego);
        })
        .catch(error=>{
            console.log(error);
            res.send("Error");
        })
}